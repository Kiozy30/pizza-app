import React from "react"
import ReactDOM from "react-dom/client"

function Header() {
  return <h1> Akio's Pizza Co.</h1>;
}

function Pizza() {
  return(
    <div>
        <img src="pizzas/spinaci.jpg"></img>
        <h4>Pizza Spinaci</h4>
        <a>Tomato, mozarella, spinach, and ricotta cheese</a>
        <p>10</p>
    </div>
  ); 
}

function App() {
  return(
    <div>
      <Header />
      <Pizza />
      <Pizza />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />)
